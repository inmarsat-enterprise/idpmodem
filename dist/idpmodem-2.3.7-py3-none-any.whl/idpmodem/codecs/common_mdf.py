"""Codec functions for IDP Common Message Format supported by Inmarsat MGS.

Also supported on ORBCOMM IGWS.

*** common_mdf DEPRECATED - use common_message_format instead ***

"""
from .common_message_format import *